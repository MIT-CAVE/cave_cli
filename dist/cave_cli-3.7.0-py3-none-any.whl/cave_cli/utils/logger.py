from collections.abc import Callable
import sys
from cave_cli.utils.display import (
    BOLD,
    DIM,
    GREEN,
    RED,
    RESET,
    YELLOW,
    CYAN,
    print_section,
    set_quiet,
)


class CaveLogger:
    """
    Usage:

    - Multi-level logger matching the bash CLI's DEBUG/INFO/WARN/ERROR/SILENT behavior

    Notes:

    - Output goes to stderr in the format ``LEVEL: message``
    - Module-level singleton ``logger`` is used throughout the package
    """

    LEVELS: dict[str, int] = {
        "DEBUG": 0,
        "INFO": 1,
        "SUCCESS": 1,
        "WARN": 2,
        "ERROR": 3,
        "SILENT": 4,
    }

    def __init__(self, level: str = "INFO") -> None:
        self._listeners: list[Callable[[str, str], None]] = []
        self.set_level(level)

    def add_listener(self, listener: Callable[[str, str], None]) -> None:
        """
        Usage:

        - Adds a callback that receives every logged message regardless of level.

        Requires:

        - ``listener``:
            - Type: Callable[[str, str], None]
            - What: Callback taking (message, level).
        """
        if listener not in self._listeners:
            self._listeners.append(listener)

    def remove_listener(self, listener: Callable[[str, str], None]) -> None:
        """
        Usage:

        - Removes a previously registered log listener callback.

        Requires:

        - ``listener``:
            - Type: Callable[[str, str], None]
            - What: The callback to remove.
        """
        if listener in self._listeners:
            self._listeners.remove(listener)

    def set_level(self, level: str) -> None:
        """
        Usage:

        - Sets the minimum log level for output

        Requires:

        - ``level``:
            - Type: str
            - What: One of DEBUG, INFO, WARN, ERROR, SILENT
        """
        level = level.upper()
        if level not in self.LEVELS:
            raise ValueError(
                f"Invalid log level {level!r}. "
                f"Must be one of: {list(self.LEVELS.keys())}"
            )
        self._level = self.LEVELS[level]
        set_quiet(level == "SILENT")

    def log(self, message: str, level: str) -> None:
        for listener in list(self._listeners):
            try:
                listener(message, level)
            except Exception:
                pass
        if self.LEVELS.get(level, 0) >= self._level:
            color = ""
            if level == "ERROR":
                color = RED
            elif level == "WARN":
                color = YELLOW
            elif level == "SUCCESS":
                color = GREEN
            elif level == "DEBUG":
                color = DIM

            prefix = f"{color}{level}:{RESET} " if level != "INFO" else ""
            sys.stderr.write(f"{prefix}{message}\n")
            sys.stderr.flush()

    def debug(self, message: str) -> None:
        self.log(message, "DEBUG")

    def info(self, message: str) -> None:
        self.log(message, "INFO")

    def success(self, message: str) -> None:
        self.log(message, "SUCCESS")

    def warn(self, message: str) -> None:
        self.log(message, "WARN")

    def error(self, message: str) -> None:
        self.log(message, "ERROR")

    def header(self, text: str) -> None:
        """
        Usage:

        - Prints a header block with separator lines at INFO level
        """
        if self._level <= self.LEVELS["INFO"]:
            print_section(text)


logger = CaveLogger()
